from phBot import *
import QtBind
import struct
import time
import threading
import os
import json
import socket

pName = 'Pirates AutoTrade'
pVersion = '1.4'

gui = QtBind.init(__name__, pName)

# Boot UI
lblBoot = QtBind.createLabel(gui, 'Pirates AutoTrade is not running', 235, 120)
lblBootInfo = QtBind.createLabel(gui, 'Reload Phbot Plugin after start -> Pirates_AutoTrade Client', 150, 150)

lblRules = None
lstRules = None
btnAddRule = None
btnRemRule = None
btnImport = None
cbxImport = None
btnSetXY = None
lblX = None
tbxX = None
lblY = None
tbxY = None
btnLoadNpc = None
cbxNpc = None
lblRange = None
cbxRange = None
lblCmd = None
cbxCmd = None
lblScript = None
btnLoadScripts = None
lblScripts = None
cbxScripts = None
btnStart = None
btnStop = None
btnForceStart = None
btnInjectCaptcha = None
lblCooldown = None
tbxCooldown = None
btnResetTime = None
btnLoadDeathScripts = None
cbxDeathScript = None
lblWaitAfterDeath = None
tbxWaitAfterDeath = None
lbltext = None

_resurrecting = False
main_gui_created = False
main_system_started = False

# State
auto_enabled = False
rules = []
last_open_time = {}
check_thread_started = False
char_loaded = False

# Helpers: Per-character Config
def get_config_folder():
    folder = os.path.join(get_config_dir(), pName)
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder

def get_config_path():
    char_data = get_character_data()
    if char_data and "name" in char_data:
        char_name = char_data["name"]
    else:
        char_name = "Unknown"
    return os.path.join(get_config_folder(), f'{char_name}.json')

def get_script_folder():
    folder = os.path.join(os.getcwd(), "Plugins", "AutoTrade", "Script")
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder

# Import config
def refresh_import_list():
    if not main_gui_created or cbxImport is None:
        return
    try:
        QtBind.clear(gui, cbxImport)
        cfg_dir = get_config_folder()
        if not os.path.exists(cfg_dir):
            return
        for f in os.listdir(cfg_dir):
            if f.endswith(".json"):
                char_name = f.replace(".json", "")
                QtBind.append(gui, cbxImport, char_name)
    except Exception as e:
        log(f'[{pName}] refresh_import_list error: {e}')

def import_config_from(char_name):
    try:
        src = os.path.join(get_config_folder(), f'{char_name}.json')
        dst = get_config_path()
        if os.path.exists(src):
            with open(src, 'r', encoding='utf-8') as f:
                data = json.load(f)
            with open(dst, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            log(f"[{pName}] Imported config from {char_name} → {os.path.basename(dst)}")
            load_rules()
        else:
            log(f"[{pName}] No config found for {char_name}")
    except Exception as e:
        log(f"[{pName}] Import error: {e}")

def btnImport_clicked():
    char_name = QtBind.text(gui, cbxImport).strip()
    if char_name:
        import_config_from(char_name)
    else:
        log(f'[{pName}] Please select character to import.')

# Script utilities
def resolve_script(script_text):
    if not script_text:
        return ('', '')
    name = script_text.strip().replace('.txt', '')
    path = os.path.join(get_script_folder(), name + '.txt')
    return (name, path)

def file_has_meaningful_content(path):
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return False
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                s = line.strip()
                if s and not s.startswith('//') and not s.startswith('#'):
                    return True
        return False
    except:
        return False

def set_training_script_safely(script_text):
    name, full_path = resolve_script(script_text)
    if not name:
        log(f'[{pName}] WARNING: Empty script name.')
        return False
    if not os.path.exists(full_path):
        log(f'[{pName}] WARNING: Script file not found: {full_path}')
        return False
    if not file_has_meaningful_content(full_path):
        log(f'[{pName}] WARNING: Script exists but seems empty or only comments: {full_path}')
    try:
        res = set_training_script(full_path)
        if res:
            #log(f'[{pName}] Training script set by FULL PATH: {full_path}')
            time.sleep(1.0)
            return True
    except Exception as e:
        log(f'[{pName}] ERROR set by full path: {e}')
    try:
        res2 = set_training_script(name)
        if res2:
            log(f'[{pName}] Training script set by NAME: {name}')
            time.sleep(1.0)
            return True
        else:
            log(f'[{pName}] ERROR: set_training_script(name) also returned None/False.')
            return False
    except Exception as e:
        log(f'[{pName}] ERROR set by name: {e}')
        return False

# Config save/load
def save_rules():
    if not main_gui_created:
        return
    data = {
        'rules': rules,
        'cooldown': safe_int(QtBind.text(gui, tbxCooldown), 100),
        'default_range': safe_int(QtBind.text(gui, cbxRange), 10),
    }
    try:
        with open(get_config_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        #log(f'[{pName}] Saved config -> {os.path.basename(get_config_path())}')
    except Exception as e:
        #log(f'[{pName}] Save error: {e}')
        pass

def render_rules_to_gui():
    if not main_gui_created or lstRules is None:
        return

    QtBind.clear(gui, lstRules)

    for rule in rules:
        try:
            QtBind.append(gui, lstRules,
                f"{rule['x']},{rule['y']} (R:{rule.get('range',10)}) "
                f"=> {rule.get('name','')} "
                f"| Cmd:{rule.get('command','')} "
                f"| Script:{rule.get('script','')} "
                f"| Death: {rule.get('death_wait',20)}s : {rule.get('death_script','')}"
            )
        except:
            pass

def load_rules():
    global rules
    try:
        cfg = get_config_path()

        if os.path.exists(cfg):
            with open(cfg, 'r', encoding='utf-8') as f:
                data = json.load(f)

            rules = data.get('rules', [])

            cd = data.get('cooldown')
            if main_gui_created and cd is not None:
                QtBind.setText(gui, tbxCooldown, str(cd))

            dr = data.get('default_range')
            if main_gui_created and dr is not None:
                QtBind.setText(gui, cbxRange, str(dr))
        else:
            rules = []

    except Exception as e:
        log(f"[{pName}] Load error: {e}")
        rules = []

    render_rules_to_gui()

# Utils
def safe_int(text, default):
    try:
        return int(str(text).strip())
    except:
        return default

def _range_or_default(val):
    r = safe_int(val, 10)
    return r if r > 0 else 1

def get_default_range_from_gui():
    if not main_gui_created or cbxRange is None:
        return 10
    return _range_or_default(QtBind.text(gui, cbxRange))

def get_cooldown():
    if not main_gui_created or tbxCooldown is None:
        return 100
    return safe_int(QtBind.text(gui, tbxCooldown), 100)

def get_position_xy():
    pos = get_position()
    if pos:
        return (pos['x'], pos['y'])
    return (0, 0)

# Server Connect
DEFAULT_PORT = 3505
SERVER_HOST = '127.0.0.1'

def is_autotrade_running(timeout=1):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((SERVER_HOST, DEFAULT_PORT))
        return True
    except:
        return False
    finally:
        try:
            s.close()
        except:
            pass

def get_autotrade_exe_path():
    candidates = [
        os.path.join(os.getcwd(), "Plugins", "AutoTrade", "Pirates_AutoTrade.exe"),
        os.path.join(os.getcwd(), "Pirates_AutoTrade.exe"),
        os.path.join(os.getcwd(), "dist", "Pirates_AutoTrade.exe"),
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "Pirates_AutoTrade.exe"),
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "dist", "Pirates_AutoTrade.exe"),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return ""

def create_main_gui():
    global main_gui_created
    global lblRules, lstRules, btnAddRule, btnRemRule, btnImport, cbxImport
    global btnSetXY, lblX, tbxX, lblY, tbxY, btnLoadNpc, cbxNpc
    global lblRange, cbxRange, lblCmd, cbxCmd, lblScript, btnLoadScripts
    global lblScripts, cbxScripts, btnStart, btnStop, btnForceStart, btnInjectCaptcha
    global lblCooldown, tbxCooldown, btnResetTime, btnLoadDeathScripts
    global cbxDeathScript, lblWaitAfterDeath, tbxWaitAfterDeath, lbltext

    if main_gui_created:
        return

    try:
        QtBind.setText(gui, lblBoot, '')
        QtBind.setText(gui, lblBootInfo, '')
    except:
        pass

    lblRules = QtBind.createLabel(gui, 'AutoTrade - Menu Orders :', 10, 10)
    lstRules = QtBind.createList(gui, 10, 30, 625, 120)
    btnAddRule = QtBind.createButton(gui, 'btnAddRule_clicked', 'Add Order', 637, 30)
    btnRemRule = QtBind.createButton(gui, 'btnRemRule_clicked', 'Remove Order', 635, 55)

    btnImport = QtBind.createButton(gui, 'btnImport_clicked', 'Import Config', 635, 125)
    cbxImport = QtBind.createCombobox(gui, 635, 105, 88, 20)

    btnSetXY = QtBind.createButton(gui, 'btnSetXY_clicked', 'Set X,Y', 5, 158)
    lblX = QtBind.createLabel(gui, 'X :', 88, 153)
    tbxX = QtBind.createLineEdit(gui, '', 105, 150, 40, 20)
    lblY = QtBind.createLabel(gui, 'Y :', 88, 175)
    tbxY = QtBind.createLineEdit(gui, '', 105, 172, 40, 20)

    btnLoadNpc = QtBind.createButton(gui, 'btnLoadNpc_clicked', 'Load NPC :', 155, 156)
    cbxNpc = QtBind.createCombobox(gui, 240, 157, 160, 20)

    lblRange = QtBind.createLabel(gui, 'R :', 405, 160)
    cbxRange = QtBind.createCombobox(gui, 420, 157, 55, 20)
    for r in [10]:
        QtBind.append(gui, cbxRange, str(r))
    QtBind.setText(gui, cbxRange, "15")

    lblCmd = QtBind.createLabel(gui, 'Command :', 480, 160)
    cbxCmd = QtBind.createCombobox(gui, 535, 157, 85, 20)
    for c in ["JG", "DW", "HT", "SAMR", "CONST", "ALX", "SpecialTrade"]:
        QtBind.append(gui, cbxCmd, c)

    lblScript = QtBind.createLabel(gui, 'Script :', 10, 198)
    btnLoadScripts = QtBind.createButton(gui, 'btnLoadScripts_clicked', 'Load Scripts', 50, 193)
    lblScripts = QtBind.createLabel(gui, 'Chose :', 135, 198)
    cbxScripts = QtBind.createCombobox(gui, 175, 195, 150, 20)

    btnInjectCaptcha = QtBind.createButton(gui, 'btnInjectCaptcha_clicked', 'Captcha Solve', 635, 200)
    btnStart = QtBind.createButton(gui, 'btnStart_clicked', 'Start Auto', 640, 240)
    btnStop = QtBind.createButton(gui, 'btnStop_clicked', 'Stop Auto', 640, 265)
    btnForceStart = QtBind.createButton(gui, 'btnForceStart_clicked', 'Start OneTime', 637, 290)

    lblCooldown = QtBind.createLabel(gui, 'Cooldown (sec) :', 10, 233)
    tbxCooldown = QtBind.createLineEdit(gui, '300', 95, 230, 35, 20)
    btnResetTime = QtBind.createButton(gui, 'btnResetTime_clicked', 'Reset Cooldown Time', 135, 229)

    btnLoadDeathScripts = QtBind.createButton(gui, 'btnLoadDeathScripts_clicked', 'Dead Script', 10, 263)
    cbxDeathScript = QtBind.createCombobox(gui, 95, 265, 150, 20)
    lblWaitAfterDeath = QtBind.createLabel(gui, 'Wait Death (s):', 250, 267)
    tbxWaitAfterDeath = QtBind.createLineEdit(gui, '20', 325, 265, 35, 20)

    lbltext = QtBind.createLabel(gui, 'Pirates - AutoTrade Plugin', 10, 295)
    main_gui_created = True

def start_main_system():
    global main_system_started, char_loaded
    if main_system_started:
        return
    main_system_started = True
    refresh_import_list()
    char_data = get_character_data()
    if char_data and "name" in char_data and char_data["name"]:
        char_loaded = True
        load_rules()
        refresh_import_list()
    check_auto_open()

def ensure_plugin_ready():
    if main_gui_created:
        return True
    if not is_autotrade_running():
        return False
    create_main_gui()
    start_main_system()
    return True

def send_command_to_client(cmd_text, port=3505, timeout=30):
    char_name = cmd_text.split(":")[1]
    start_time = time.time()

    while time.time() - start_time < timeout:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        try:
            s.connect(('127.0.0.1', port))
            s.sendall(cmd_text.encode())

            while True:
                try:
                    data = s.recv(1024)
                    if data:
                        data = data.decode().strip().lower()
                        if data == f"done {char_name.lower()}":
                            return True
                except socket.timeout:
                    pass
                if time.time() - start_time > timeout:
                    return False
                time.sleep(0.1)
        except Exception as e:
            pass
        finally:
            s.close()
        time.sleep(1)
    return False


# Button Handlers
def btnAddRule_clicked():
    global rules
    try:
        x = int(QtBind.text(gui, tbxX))
        y = int(QtBind.text(gui, tbxY))
        name = QtBind.text(gui, cbxNpc).strip()
        rng = safe_int(QtBind.text(gui, cbxRange), 10)
        cmd = QtBind.text(gui, cbxCmd).strip()
        script = QtBind.text(gui, cbxScripts).strip()

        # Death per rule
        death_script = QtBind.text(gui, cbxDeathScript).strip()
        death_wait = safe_int(QtBind.text(gui, tbxWaitAfterDeath), 20)

        if not name:
            return

        rule = {
            'x': x,
            'y': y,
            'name': name,
            'range': rng,
            'command': cmd,
            'script': script,
            'death_script': death_script,
            'death_wait': death_wait
        }

        rules.append(rule)

        QtBind.append(gui, lstRules,
            f"{x},{y} (R:{rng}) => {name} | Cmd:{cmd} | Script:{script} "
            f"| Death: {death_wait}s : {death_script}"
        )

        save_rules()

    except:
        pass

def btnRemRule_clicked():
    index = QtBind.currentIndex(gui, lstRules)
    if 0 <= index < len(rules):
        removed = rules.pop(index)
        QtBind.removeAt(gui, lstRules, index)
        save_rules()
        #log(f'[{pName}] Rule removed: {removed.get("name","?")}')

def btnStart_clicked():
    global auto_enabled
    auto_enabled = True
    #log(f'[{pName}] Auto open is always enabled.')

def btnStop_clicked():
    global auto_enabled
    auto_enabled = False
    #log(f'[{pName}] Auto open cannot be stopped (Always ON).')

def btnInjectCaptcha_clicked():
    try:
        inject_joymax(0xC011, bytearray.fromhex("D2 7C F3 7A DB"), False)
        #log(f"[{pName}] Injected packet 0xC011")
    except Exception as e:
        #log(f"[{pName}] Inject failed: {e}")
        pass

def btnSetXY_clicked():
    pos = get_position()
    if pos:
        x = int(pos['x'])
        y = int(pos['y'])
        QtBind.setText(gui, tbxX, str(x))
        QtBind.setText(gui, tbxY, str(y))
        #log(f"[{pName}] X,Y set to ({pos['x']}, {pos['y']})")
    else:
        #log(f"[{pName}] Unable to get character position")
        pass
    
def btnLoadNpc_clicked():
    QtBind.clear(gui, cbxNpc)
    nearby = get_npcs()

    if not nearby:
        #log(f"[{pName}] No NPCs found nearby.")
        return

    count = 0
    for uid, data in nearby.items():
        name = data.get("name", "")
        if name.startswith(""):
            QtBind.append(gui, cbxNpc, name)
            count += 1

    #log(f"[{pName}] NPC list refreshed ({len(nearby)} NPCs).")

# Death Script Load
def btnLoadDeathScripts_clicked():
    QtBind.clear(gui, cbxDeathScript)
    seen = set()
    for folder in [get_script_folder(), os.path.join(get_config_dir(),"Script")]:
        if os.path.exists(folder):
            files = [f.replace('.txt','') for f in os.listdir(folder) if f.endswith('.txt')]
            for f in files:
                if f not in seen:
                    QtBind.append(gui, cbxDeathScript, f)
                    seen.add(f)

# Death Handler
def handle_death():
    global _resurrecting
    if _resurrecting:
        return
    _resurrecting = True
    threading.Thread(target=_death_thread, daemon=True).start()

def _death_thread():
    global _resurrecting
    try:
        for rule in rules:
            script = rule.get('death_script', '')
            wait_time = rule.get('death_wait', 20)

            if script:
                log(f"[{pName}] Executing death script: {script}")
                time.sleep(wait_time)

                stop_bot()
                time.sleep(1)

                if set_training_script_safely(script):
                    time.sleep(2)
                    start_bot()
                    log(f"[{pName}] Death script started.")

                return

        log(f"[{pName}] No death script configured in rules.")

    finally:
        _resurrecting = False

# Extend Events

# ===== Handle Events =====
def handle_event(event, data):
    global auto_enabled, char_loaded

    if event == "connected":
        auto_enabled = True
        char_loaded = False

        char_data = get_character_data()
        if char_data and "name" in char_data and char_data["name"]:
            char_loaded = True
            load_rules()
            refresh_import_list()

    elif event == "disconnected":
        save_rules()
        char_loaded = False

    elif str(event) == "7":  # EVENT_DIED
        handle_death()


def btnForceStart_clicked():
    x, y = get_position_xy()
    for rule in rules:
        rx, ry = rule['x'], rule['y']
        name = rule['name']
        rng = rule.get('range', '')
        cmd = rule.get('command', '')
        script = rule.get('script', '')
        dist = ((rx - x)**2 + (ry - y)**2) ** 0.5
        if dist <= rng:
            #log(f"[{pName}] Force opening NPC '{name}' at distance {dist:.2f} (R:{rng})")
            open_npc_by_name(name, cmd, script)
            return
    #log(f"[{pName}] No matching rule within range for Force Start.")

def btnResetTime_clicked():
    global last_open_time
    last_open_time = {}
    #log(f"[{pName}] All cooldown timers have been reset.")

def btnLoadScripts_clicked():
    try:
        script_dir = get_script_folder()
        if not os.path.exists(script_dir):
            return
        files = [f.replace('.txt', '') for f in os.listdir(script_dir) if f.endswith('.txt')]
        QtBind.clear(gui, cbxScripts)
        if files:
            for f in files:
                QtBind.append(gui, cbxScripts, f)
            QtBind.setText(gui, cbxScripts, files[0])
            cbxScripts_changed()
        else:
            log(f"[{pName}] No .txt scripts found in Script folder.")
    except Exception as e:
        log(f"[{pName}] Error loading scripts: {e}")

def cbxScripts_changed():
    selected = QtBind.text(gui, cbxScripts)
    if selected:
        set_training_script_safely(selected)

# ===== Core Logic =====
def open_npc_by_name(name, cmd, script):
    nearby = get_npcs()
    npc_id = None
    for uid, data in nearby.items():
        if data.get('name', '') == name:
            npc_id = uid
            break
    if not npc_id:
        log(f"[{pName}] NPC '{name}' not found nearby.")
        return False

    stop_bot()
    log(f"[{pName}] Bot stopped.")
    time.sleep(2)

    try:
        inject_joymax(0x7045, struct.pack('<I', npc_id), False)
    except Exception as e:
        #log(f"[{pName}] Error injecting NPC packet: {e}")
        return False
    time.sleep(2)

    if script:
        if set_training_script_safely(script):
            pass
            #log(f"[{pName}] Script '{script}' set successfully.")
        else:
            pass
            #log(f"[{pName}] WARNING: Script '{script}' could not be set, skipping.")
    time.sleep(2)

    char_data = get_character_data()
    char_name = char_data['name'] if (char_data and 'name' in char_data) else ''
    if cmd and char_name:
        success = send_command_to_client(f"{cmd}:{char_name}")
        if success:
            log(f"[{pName}] Server confirmed done for '{char_name}'")
        else:
            log(f"[{pName}] WARNING: Did not receive 'done {char_name}' from server.")
        inject_joymax(0x704B, b'', False)
        time.sleep(2)
        start_bot()

    return True

def wait_for_done(char_name):
    try:
        target_line = f"done {char_name}".lower()
        path = os.path.join(os.getcwd(), "Plugins\AutoTrade\Command.txt")
        log(f"[{pName}] Waiting for '{target_line}' in Command.txt...")
        while True:
            try:
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        lines = f.readlines()
                    found_idx = -1
                    for i, line in enumerate(lines):
                        if target_line in line.lower():
                            found_idx = i
                            break
                    if found_idx != -1:
                        del lines[found_idx]
                        with open(path, "w", encoding="utf-8") as f:
                            f.writelines(lines)
                        inject_joymax(0x704B, b'', False)
                        #log(f"[{pName}] NPC window closed (found '{target_line}')")
                        time.sleep(2)
                        start_bot()
                        #log(f"[{pName}] Bot resumed")
                        return
                time.sleep(1)
            except:
                return
    except:
        return

def check_auto_open():
    global check_thread_started
    if check_thread_started:
        return
    check_thread_started = True
    def loop():
        while True:
            try:
                if auto_enabled:
                    x, y = get_position_xy()
                    for rule in list(rules):
                        rx, ry = rule['x'], rule['y']
                        name = rule['name']
                        rng = rule.get('range', 10)
                        cmd = rule.get('command', '')
                        script = rule.get('script', '')
                        dist = ((rx - x)**2 + (ry - y)**2) ** 0.5
                        if dist <= rng:
                            now = time.time()
                            last = last_open_time.get(name, 0)
                            cooldown = get_cooldown()
                            if now - last >= cooldown:
                                log(f"[{pName}] Order Running for '{cmd}'")
                                if open_npc_by_name(name, cmd, script):
                                    last_open_time[name] = now
                            else:
                                remaining = int(cooldown - (now - last))
                                #log(f"[{pName}] '{name}' cooldown: {remaining}s")
                time.sleep(5)
            except Exception as e:
                #log(f'[{pName}] check loop error: {e}')
                time.sleep(5)
    threading.Thread(target=loop, daemon=True).start()

# Auto load config when char is ready
def check_char_loop():
    global char_loaded
    while True:
        try:
            if not char_loaded:
                char_data = get_character_data()
                if char_data and "name" in char_data and char_data["name"]:
                    char_loaded = True
                    #log(f"[{pName}] Character detected: {char_data['name']}, loading config...")
                    load_rules()
                    refresh_import_list()
            time.sleep(1)
        except Exception as e:
            #log(f"[{pName}] check_char_loop error: {e}")
            time.sleep(1)


# Init
ensure_plugin_ready()
threading.Thread(target=check_char_loop, daemon=True).start()
log(f"{pName} v{pVersion} loaded.")
