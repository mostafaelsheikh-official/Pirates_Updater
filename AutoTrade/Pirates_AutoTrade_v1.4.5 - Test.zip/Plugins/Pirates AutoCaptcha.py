from phBot import *

import threading
import time
import json
import socket

pName = 'Pirates AutoCaptcha'
pVersion = '1.4'

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 3506
CAPTCHA_OPCODE = 0xC011
INTERVAL = 60

last_packet_data = None


def to_hex(data):
    return ' '.join('{:02X}'.format(b) for b in data)

def from_hex(hexstr):
    return bytearray(int(x, 16) for x in hexstr.split())

def get_account_identity():
    try:
        char_data = get_character_data() or {}
        server = str(char_data.get('server', '')).strip()
        name = str(char_data.get('name', '')).strip()
        return server, name
    except:
        return "", ""

def send_packet(opcode, data):
    try:
        server_name, character_name = get_account_identity()
        payload = {
            "opcode": opcode,
            "packet": to_hex(data),
            "server_name": server_name,
            "character_name": character_name
        }
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5)
        client.connect((SERVER_HOST, SERVER_PORT))
        client.sendall(json.dumps(payload).encode("utf-8"))
        res_text = client.recv(8192).decode("utf-8", errors="ignore").strip()
        if not res_text:
            return None, None
        res = json.loads(res_text)
        if "opcode" in res and "packet" in res:
            return res["opcode"], res["packet"]
    except Exception as e:
        pass
    finally:
        try:
            client.close()
        except:
            pass
    return None, None

def handle_silkroad(opcode, data):
    global last_packet_data

    if opcode != CAPTCHA_OPCODE:
        return True


    last_packet_data = bytearray(data)

    new_opcode, new_packet = send_packet(opcode, data)

    if new_packet:
        inject_joymax(new_opcode, from_hex(new_packet), False)
    else:
        pass
    return True

def heartbeat_loop():
    global last_packet_data


    while True:
        time.sleep(INTERVAL)

        if not last_packet_data:
            continue


        new_opcode, new_packet = send_packet(CAPTCHA_OPCODE, last_packet_data)

        if new_packet:
            inject_joymax(new_opcode, from_hex(new_packet), False)

log(f"{pName} v{pVersion} loaded.")

threading.Thread(target=heartbeat_loop, daemon=True).start()
