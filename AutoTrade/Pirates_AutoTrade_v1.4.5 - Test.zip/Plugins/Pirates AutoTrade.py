from phBot import *
import struct
import time
import threading
import os
import json
import socket
import uuid

pName = 'Pirates AutoTrade'
pVersion = '1.5.0'

CLIENT_HOST = '127.0.0.1'
CLIENT_PORT = 3517
SOCKET_TIMEOUT = 8
POLL_INTERVAL = 0.35
MAX_EVENTS = 80
SESSION_ID = uuid.uuid4().hex

ORDER_MODE_SELL_BUY = "Sell&Buy"
ORDER_MODE_SELL_ONLY = "Sell Only"

events_lock = threading.Lock()
events = []
event_id = 0


def normalize_order_mode(order_mode):
    value = str(order_mode or "").strip().lower().replace("_", " ").replace("-", " ")
    compact = "".join(ch for ch in value if ch.isalnum())
    if compact == "sellonly":
        return ORDER_MODE_SELL_ONLY
    return ORDER_MODE_SELL_BUY


def json_safe(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return str(value)


def safe_config_filename(text):
    text = str(text or "").strip()
    invalid_chars = '<>:"/\\|?*'
    cleaned = ''.join('_' if (ch in invalid_chars or ord(ch) < 32) else ch for ch in text)
    cleaned = cleaned.strip(" .")
    return cleaned or "Unknown"


def _first_character_value(char_data, keys, default):
    for key in keys:
        value = char_data.get(key) if char_data else None
        if value:
            return str(value)
    return default


def get_limit_identity():
    char_data = get_character_data() or {}
    character = _first_character_value(char_data, ["name", "char_name", "character"], "Unknown")
    account = _first_character_value(
        char_data,
        ["account", "account_name", "username", "user", "login"],
        character
    )
    server = _first_character_value(
        char_data,
        ["server", "server_name", "servername", "shard", "shard_name", "world"],
        "UnknownServer"
    )
    return server, account, character


def build_account_id(identity):
    server = str(identity.get("server") or "UnknownServer").strip()
    account = str(identity.get("account") or "Unknown").strip()
    character = str(identity.get("character") or "Unknown").strip()
    if server == "UnknownServer" and account == "Unknown" and character == "Unknown":
        return f"loading|{SESSION_ID}"
    return f"{server}|{account}|{character}"


def get_character_config_name(server=None, character=None):
    if server is None or character is None:
        server, _account, character = get_limit_identity()
    return safe_config_filename(f"{server}_{character}")


def get_config_folder():
    folder = os.path.join(get_config_dir(), pName)
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder


def get_legacy_config_path():
    server, _account, character = get_limit_identity()
    cfg_dir = get_config_folder()
    config_path = os.path.join(cfg_dir, f'{get_character_config_name(server, character)}.json')
    legacy_path = os.path.join(cfg_dir, f'{safe_config_filename(character)}.json')
    if legacy_path != config_path and os.path.exists(legacy_path) and not os.path.exists(config_path):
        return legacy_path
    return config_path


def read_legacy_config():
    path = get_legacy_config_path()
    if not os.path.exists(path):
        return {"ok": False, "error": "not_found"}
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return {"ok": True, "path": path, "data": data}


def get_script_folder():
    folder = os.path.join(os.getcwd(), "Plugins", "AutoTrade", "Script")
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder


def get_dead_town_folder():
    folder = os.path.join(get_script_folder(), "DeadTown")
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder


def normalize_script_name(script_text):
    text = str(script_text or "").strip()
    text = os.path.basename(text)
    if text.lower().endswith(".txt"):
        text = text[:-4]
    return text.strip()


def resolve_script(script_text, script_folder=None):
    name = normalize_script_name(script_text)
    if not name:
        return ('', '')
    folder = script_folder or get_script_folder()
    path = os.path.join(folder, name + '.txt')
    return (name, path)


def file_has_meaningful_content(path):
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return False
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                s = line.strip()
                if s and not s.startswith('//') and not s.startswith('#'):
                    return True
        return False
    except:
        return False


def set_training_script_safely(script_text, script_folder=None):
    name, full_path = resolve_script(script_text, script_folder)
    if not name:
        return {"ok": False, "error": "empty_script"}
    if not os.path.exists(full_path):
        return {"ok": False, "error": "script_not_found", "path": full_path}
    if not file_has_meaningful_content(full_path):
        log(f'[{pName}] WARNING: Script seems empty or only comments: {full_path}')
    try:
        res = set_training_script(full_path)
        if res:
            time.sleep(1.0)
            return {"ok": True, "name": name, "path": full_path}
    except Exception as e:
        last_error = str(e)
    else:
        last_error = "set_by_full_path_failed"
    if script_folder is not None:
        return {"ok": False, "error": last_error, "path": full_path}
    try:
        res2 = set_training_script(name)
        if res2:
            time.sleep(1.0)
            return {"ok": True, "name": name, "path": full_path}
        return {"ok": False, "error": "set_by_name_failed", "path": full_path}
    except Exception as e:
        return {"ok": False, "error": str(e), "path": full_path}


def list_scripts(folder):
    try:
        if not os.path.exists(folder):
            os.makedirs(folder)
        return sorted(
            f[:-4]
            for f in os.listdir(folder)
            if f.lower().endswith(".txt")
        )
    except:
        return []


def get_position_xy():
    try:
        pos = get_position() or {}
        return {
            "x": int(pos.get("x", 0)),
            "y": int(pos.get("y", 0))
        }
    except:
        return {"x": 0, "y": 0}


def get_npc_list():
    result = []
    try:
        nearby = get_npcs() or {}
        for uid, data in nearby.items():
            result.append({
                "uid": uid,
                "name": str(data.get("name", "")),
                "type": str(data.get("type", "")),
            })
    except:
        pass
    return result


def get_status_payload():
    server, account, character = get_limit_identity()
    char_data = get_character_data() or {}
    return {
        "ok": True,
        "agent_version": pVersion,
        "session_id": SESSION_ID,
        "identity": {
            "server": server,
            "account": account,
            "character": character,
        },
        "character_data": json_safe(char_data),
        "position": get_position_xy(),
        "scripts": list_scripts(get_script_folder()),
        "death_scripts": list_scripts(get_dead_town_folder()),
    }


def add_event(event, data=None):
    global event_id
    with events_lock:
        event_id += 1
        events.append({
            "id": event_id,
            "event": str(event),
            "data": json_safe(data),
            "time": time.time(),
        })
        while len(events) > MAX_EVENTS:
            events.pop(0)


def get_events_snapshot():
    with events_lock:
        return [dict(event) for event in events]


def clear_events_until(max_id):
    try:
        max_id = int(max_id)
    except:
        return
    with events_lock:
        remaining = [
            event for event in events
            if int(event.get("id", 0)) > max_id
        ]
        events[:] = remaining


def open_npc_by_name(name, script=""):
    name = str(name or "").strip()
    if not name:
        return {"ok": False, "error": "empty_npc"}

    nearby = get_npcs() or {}
    npc_id = None
    for uid, data in nearby.items():
        if str(data.get('name', '')) == name:
            npc_id = uid
            break
    if not npc_id:
        return {"ok": False, "error": "npc_not_found", "npc": name}

    stop_bot()
    time.sleep(2)

    try:
        inject_joymax(0x7045, struct.pack('<I', npc_id), False)
    except Exception as e:
        return {"ok": False, "error": "open_packet_failed", "detail": str(e)}

    time.sleep(2)

    script_result = {"ok": True}
    if script:
        script_result = set_training_script_safely(script)

    char_data = get_character_data() or {}
    server, account, character = get_limit_identity()
    return {
        "ok": True,
        "npc": name,
        "script": script_result,
        "identity": {
            "server": server,
            "account": account,
            "character": character,
        },
        "character": str(char_data.get("name", character)),
    }


def finish_order():
    try:
        inject_joymax(0x704B, b'', False)
    except:
        pass
    time.sleep(2)
    try:
        start_bot()
    except:
        pass
    return {"ok": True}


def run_death_script(script, wait_time=20):
    script = normalize_script_name(script)
    try:
        wait_time = max(0, int(wait_time))
    except:
        wait_time = 20
    if not script:
        return {"ok": False, "error": "empty_script"}
    time.sleep(wait_time)
    try:
        stop_bot()
    except:
        pass
    time.sleep(1)
    result = set_training_script_safely(script, get_dead_town_folder())
    if result.get("ok"):
        time.sleep(2)
        try:
            start_bot()
        except:
            pass
    return result


def dispatch_command(command):
    action = str(command.get("action", "")).strip()
    data = command.get("data") or {}

    if action == "ping":
        return {"ok": True, "agent_version": pVersion}
    if action == "status":
        return get_status_payload()
    if action == "npcs":
        return {"ok": True, "npcs": get_npc_list()}
    if action == "scripts":
        return {
            "ok": True,
            "scripts": list_scripts(get_script_folder()),
            "death_scripts": list_scripts(get_dead_town_folder()),
        }
    if action == "open_npc":
        return open_npc_by_name(data.get("name", ""), data.get("script", ""))
    if action == "finish_order":
        return finish_order()
    if action == "set_script":
        return set_training_script_safely(data.get("script", ""))
    if action == "run_death_script":
        return run_death_script(data.get("script", ""), data.get("wait", 20))
    if action == "start_bot":
        start_bot()
        return {"ok": True}
    if action == "stop_bot":
        stop_bot()
        return {"ok": True}
    if action == "inject_captcha":
        inject_joymax(0xC011, bytearray.fromhex("D2 7C F3 7A DB"), False)
        return {"ok": True}
    if action == "legacy_config":
        return read_legacy_config()

    return {"ok": False, "error": "unknown_action", "action": action}


def send_poll(payload):
    client = None
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(SOCKET_TIMEOUT)
        client.connect((CLIENT_HOST, CLIENT_PORT))
        client.sendall(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        try:
            client.shutdown(socket.SHUT_WR)
        except:
            pass
        chunks = []
        while True:
            chunk = client.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
        if not chunks:
            return {"ok": False, "error": "empty_response"}
        return json.loads(b"".join(chunks).decode("utf-8", errors="ignore"))
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        try:
            if client:
                client.close()
        except:
            pass


def poll_loop():
    last_result = None
    connection_state = ""
    while True:
        try:
            status = get_status_payload()
            identity = status.get("identity") or {}
            pending_events = get_events_snapshot()
            payload = {
                "type": "poll",
                "session_id": SESSION_ID,
                "account_id": build_account_id(identity),
                "identity": identity,
                "status": status,
                "events": pending_events,
                "result": last_result,
            }
            max_event_id = 0
            for event in pending_events:
                try:
                    max_event_id = max(max_event_id, int(event.get("id", 0)))
                except:
                    pass

            last_result = None
            response = send_poll(payload)
            if response.get("ok"):
                if max_event_id:
                    clear_events_until(max_event_id)
                if connection_state != "connected":
                    log(f"[{pName}] Connected to Pirates_AutoTrade Client")
                    connection_state = "connected"
                command = response.get("command")
                if isinstance(command, dict):
                    command_id = str(command.get("id", ""))
                    try:
                        result = dispatch_command(command)
                    except Exception as e:
                        result = {"ok": False, "error": "command_exception", "detail": str(e)}
                    last_result = {
                        "id": command_id,
                        "response": result,
                    }
                    continue
            else:
                if connection_state != "failed":
                    log(f"[{pName}] Failed Connect to Pirates_AutoTrade Client")
                    connection_state = "failed"
        except Exception as e:
            if connection_state != "failed":
                log(f"[{pName}] Failed Connect to Pirates_AutoTrade Client")
                connection_state = "failed"
        time.sleep(POLL_INTERVAL)


def handle_event(event, data):
    add_event(event, data)


threading.Thread(target=poll_loop, daemon=True).start()
add_event("loaded", {"version": pVersion})
log(f"{pName} v{pVersion} loaded.")
